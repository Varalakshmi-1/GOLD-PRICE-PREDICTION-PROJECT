from flask import Flask, render_template, request
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import yfinance as yf

app = Flask(__name__)

def get_gold_data():
    # Example: Using yfinance to get gold price data from Yahoo Finance
    gold_data = yf.download("GLD", start="2020-01-01", end="2022-01-01")
    return gold_data

def train_model(gold_data):
    # Assuming a simple linear regression model for demonstration purposes
    gold_data['Date'] = gold_data.index
    gold_data['Date'] = gold_data['Date'].dt.date
    gold_data['Date'] = gold_data['Date'].apply(lambda x: x.toordinal())

    X = gold_data[['Date']]
    y = gold_data['Close']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = LinearRegression()
    model.fit(X_train, y_train)

    return model

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    date_input = request.form['date']
    date_ordinal = pd.to_datetime(date_input).toordinal()

    model = train_model(get_gold_data())
    prediction = model.predict([[date_ordinal]])

    return render_template('index.html', prediction=prediction[0], date=date_input)

if __name__ == '__main__':
    app.run(debug=True)